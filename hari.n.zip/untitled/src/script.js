// Typing effect
const typingText = ["Frontend Developer", "Web Designer", "Coder"];
let i = 0, j = 0, current = "", isDeleting = false;
function type() {
  if (i < typingText.length) {
    if (!isDeleting && j <= typingText[i].length) {
      current = typingText[i].substring(0, j++);
    } else if (isDeleting && j >= 0) {
      current = typingText[i].substring(0, j--);
    }
    document.getElementById("typing").innerText = current;
    if (j === typingText[i].length) isDeleting = true;
    if (isDeleting && j === 0) { isDeleting = false; i++; if (i === typingText.length) i = 0; }
  }
  setTimeout(type, isDeleting ? 100 : 150);
}
type();

// Back to top
const toTop = document.getElementById("toTop");
window.addEventListener("scroll", () => {
  toTop.style.display = window.scrollY > 300 ? "block" : "none";
});
toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

// Theme toggle
const themeToggle = document.getElementById("themeToggle");
themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("light-mode");
  themeToggle.textContent = document.body.classList.contains("light-mode") ? "🌞" : "🌙";
});